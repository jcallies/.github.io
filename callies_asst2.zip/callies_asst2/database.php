<?php
// Josh Callies
// SPC Student ID: 2430807
// Collaboration: I worked alone

//create PDO object and connect parts_dude to pcparts database
    $dsn = 'mysql:host=localhost;dbname=pcparts';
    $username = 'parts_dude';
    $password = 'P@rtzer';

// include exception handling
    try {
        $db = new PDO($dsn, $username, $password);
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        include('database_error.php');
        exit();
    }
?>
