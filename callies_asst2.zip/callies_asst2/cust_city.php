<?php
// Josh Callies
// SPC Student ID: 2430807
// Collaboration: I worked alone

//call database.php with require_once function
require_once('database.php');

//read city from the index.html form into a variable 
$city = filter_input(INPUT_POST, 'city');

//Query to retrieve all fields from customers db for specified city
$queryCustomers = 'SELECT * FROM customers WHERE city = :city'; 
$statement1 = $db->prepare($queryCustomers);
$statement1->bindValue(':city', $city);    
$statement1->execute();
$customers = $statement1->fetchAll();
$statement1->closeCursor();
?>

<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>Customers by City</title>
    <link rel="stylesheet" type="text/css" href="main.css" >
</head>

<!-- the body section -->
<body>
<main>
    <h1>Customers by City</h1>
    <section>
        <!-- display a table of customer attributes -->
        <h2> <?php echo $city;?></h2>
        <table>
            <tr>
                <th>CustID</th>
                <th>Name</th>
                <th>Address</th>
                <th>City</th>
                <th>State</th>
                <th>Zip</th>
            </tr>

            <?php foreach ($customers as $customer) : ?>
            <tr>
                <td><?php echo $customer['custid']; ?></td>
                <td><?php echo $customer['name']; ?></td>
                <td><?php echo $customer['address']; ?></td> 
                <td><?php echo $customer['city']; ?></td>
                <td><?php echo $customer['state']; ?></td>
                <td><?php echo $customer['zip']; ?></td>
            </tr>
            <?php endforeach; ?>            
        </table>
    </section>
</main>    
<footer></footer>
</body>
</html>